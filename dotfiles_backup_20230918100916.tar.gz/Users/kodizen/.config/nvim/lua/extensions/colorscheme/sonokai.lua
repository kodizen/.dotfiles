cmd[[let g:sonokai_transparent_background = 1]]
cmd("color " .. theme)

