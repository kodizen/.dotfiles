cmd [[
let g:gruvbox_material_background = 'medium'
]]

cmd("color " .. theme)


