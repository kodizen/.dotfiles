vim.g.tokyodark_enable_italic_comment = true
vim.g.tokyodark_enable_italic = true

cmd("color " .. theme)
