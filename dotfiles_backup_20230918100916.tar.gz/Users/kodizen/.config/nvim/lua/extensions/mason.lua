--[[
  File: mason.lua
  Description: Mason plugin configuration (with lspconfig)
  See: https://github.com/williamboman/mason.nvim
]]

local mason = require("mason")
local mason_lspconfig = require("mason-lspconfig")
local lspconfig = require("lspconfig")

mason.setup()
mason_lspconfig.setup({
  ensure_installed = {
    "lua_ls",             -- LSP for Lua language
    "tsserver",           -- LSP for Typescript and Javascript
    "emmet_ls",           -- LSP for Emmet (Vue, HTML, CSS)
    "cssls",              -- LSP for CSS
    "pyright",            -- LSP for Python
    "volar",              -- LSP for Vue
    "gopls",              -- LSP for Go
    "eslint",             -- LSP for Javascript and Typescript
    "bashls",             -- LSP for Bash
    "dockerls",           -- LSP for Docker
    "html",               -- LSP for HTML
    "jsonls",             -- LSP for JSON
    "intelephense",       -- LSP for PHP
    "rust_analyzer",      -- LSP for Rust
    "vuels",              -- LSP for Vue
  }
});

-- Setup every needed language server in lspconfig
mason_lspconfig.setup_handlers {
  function (server_name)
    lspconfig[server_name].setup {}
  end,
}
